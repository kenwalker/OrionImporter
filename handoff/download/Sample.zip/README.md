README for a Sample
===================

This is a sample readme and should be the file you end up in after the import of Sample.zip

See the sample for an [Orion Importer](http://kenwalker.github.io/).